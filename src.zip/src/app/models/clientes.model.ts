export class Clientes {
  constructor(
    public _id: String,
    public nombre: String,
    public apellido: String,
    public password: String,
    public rol: String,
    public usuario: String,
    public direccion:String,
    public ciudad:String,
    public telefono:String,
    public sucripcion:String,
    public sexo:String,
  ){
  }
}
