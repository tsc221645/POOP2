import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-router',
  templateUrl: './default-router.component.html',
  styleUrls: ['./default-router.component.scss']
})
export class DefaultRouterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}
