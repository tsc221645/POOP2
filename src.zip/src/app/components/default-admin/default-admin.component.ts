import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-admin',
  templateUrl: './default-admin.component.html',
  styleUrls: ['./default-admin.component.scss']
})
export class DefaultAdminComponent implements OnInit{
  constructor() { }

  ngOnInit(): void {
  }
}
